#!/usr/bin/env python3
"""OH CR-CC(2,4) basis-transfer evidence.

Purpose
-------
Resolve the basis dependence of the connected-quadruples EA contribution
without running full CCSDTQ/aug-cc-pVTZ.

The expensive full iterative aug-DZ anchor is reused from
``runs/oh_post_ccsdt_20261006/result.json``.

For aug-cc-pVDZ and aug-cc-pVTZ, neutral and anion are computed with CCpy:

    CCSD
    HBar(CCSD)
    left-CCSD
    CR-CC(2,3)
    CR-CC(2,4)

All CR variants A/B/C/D are retained.  The difference CR24-CR23 is used only
for DZ->TZ basis transfer; it is not identified with full CCSDTQ-CCSDT.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path

from pyscf import gto, scf
from ccpy.drivers.driver import Driver

from openea_benchmark.adaptive.run_feedback import ProgressReporter
from openea_benchmark.attachment.cbs_component_evidence import (
    load_reference_geometries,
)
from openea_benchmark.attachment.post_cc_crcc24_transfer import (
    VARIANTS,
    build_crcc24_transfer_evidence,
)

HARTREE_TO_EV = 27.211386245988
BASIS_BY_X = {2: "aug-cc-pvdz", 3: "aug-cc-pvtz"}


def default_run_id() -> str:
    return os.environ.get("OPENEA_RUN_ID") or (
        "oh_crcc24_transfer_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    )


def load_json(path: Path) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))


def load_exact_t4_dz(source_run_dir: Path) -> float:
    data = load_json(source_run_dir / "result.json")
    points = data.get("points", [])
    for point in points:
        if int(point.get("cardinal", -1)) == 2:
            value = point.get("delta_t4_ev")
            if value is None:
                break
            return float(value)
    raise RuntimeError(
        f"Could not locate exact full CCSDTQ-CCSDT DZ increment in "
        f"{source_run_dir / 'result.json'}"
    )


def make_mf(*, role: str, basis: str, r_angstrom: float, max_memory_mb: int):
    charge = 0 if role == "neutral" else -1
    spin = 1 if role == "neutral" else 0
    mol = gto.M(
        atom=f"O 0 0 0; H 0 0 {r_angstrom}",
        basis=basis,
        charge=charge,
        spin=spin,
        unit="Angstrom",
        symmetry="C1",
        cart=False,
        verbose=0,
        max_memory=max_memory_mb,
    )
    mf = scf.ROHF(mol) if spin else scf.RHF(mol)
    mf.conv_tol = 1.0e-10
    mf.max_cycle = 150
    mf.kernel()
    if not mf.converged:
        mf2 = mf.newton()
        mf2.conv_tol = 1.0e-10
        mf2.max_cycle = 150
        mf2.kernel(mo_coeff=mf.mo_coeff, mo_occ=mf.mo_occ)
        mf = mf2
    if not mf.converged:
        raise RuntimeError(f"SCF failed for {role} {basis}")
    return mf


def finite_variant_dict(raw, label: str) -> dict[str, float]:
    if not isinstance(raw, dict):
        raise RuntimeError(f"{label} did not return a variant dictionary")
    out = {}
    for variant in VARIANTS:
        if variant not in raw:
            raise RuntimeError(f"{label} missing variant {variant}: {raw}")
        out[variant] = float(raw[variant])
    return out


def run_cr_pair(
    *,
    role: str,
    basis: str,
    cardinal: int,
    r_angstrom: float,
    point_dir: Path,
    max_memory_mb: int,
) -> dict:
    path = point_dir / f"X{cardinal}__{role}__CRCC23_CRCC24.json"
    if path.is_file():
        data = load_json(path)
        if (
            data.get("status") == "COMPLETED"
            and data.get("role") == role
            and data.get("basis") == basis
            and abs(float(data.get("r_angstrom")) - r_angstrom) <= 1.0e-10
        ):
            return data

    mf = make_mf(
        role=role,
        basis=basis,
        r_angstrom=r_angstrom,
        max_memory_mb=max_memory_mb,
    )
    driver = Driver.from_pyscf(mf, nfrozen=1)
    driver.options["energy_convergence"] = 1.0e-08
    driver.options["amp_convergence"] = 1.0e-08
    driver.options["maximum_iterations"] = 100

    driver.run_cc(method="ccsd")
    driver.run_hbar(method="ccsd")
    driver.run_leftcc(method="left_ccsd")

    driver.run_ccp3(method="crcc23")
    delta23 = finite_variant_dict(driver.deltap3[0], "CR-CC(2,3)")

    driver.run_ccp4(method="crcc24")
    delta24 = finite_variant_dict(driver.deltap4[0], "CR-CC(2,4)")

    base_total = float(driver.system.reference_energy) + float(driver.correlation_energy)
    total23 = {v: base_total + delta23[v] for v in VARIANTS}
    total24 = {v: base_total + delta24[v] for v in VARIANTS}

    payload = {
        "status": "COMPLETED",
        "role": role,
        "basis": basis,
        "cardinal": cardinal,
        "r_angstrom": r_angstrom,
        "nfrozen_spatial_orbitals": 1,
        "reference_energy_hartree": float(driver.system.reference_energy),
        "ccsd_correlation_hartree": float(driver.correlation_energy),
        "ccsd_total_hartree": base_total,
        "crcc23_correction_hartree": delta23,
        "crcc24_correction_hartree": delta24,
        "crcc23_total_hartree": total23,
        "crcc24_total_hartree": total24,
    }
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return payload


def ea_by_variant(neutral: dict, anion: dict, key: str) -> dict[str, float]:
    return {
        v: (
            float(neutral[key][v]) - float(anion[key][v])
        ) * HARTREE_TO_EV
        for v in VARIANTS
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source-run-id", default="oh_post_ccsdt_20261006")
    p.add_argument("--reference-run-id", default="oh_diffuse_x5_resume_20261003")
    p.add_argument("--reference-basis", default="d-aug-cc-pv5z")
    p.add_argument("--run-root", default="runs")
    p.add_argument("--run-id", default=default_run_id())
    p.add_argument("--max-memory-mb", type=int, default=96000)
    args = p.parse_args()

    run_root = Path(args.run_root)
    run_dir = run_root / args.run_id
    point_dir = run_dir / "points"
    source_run_dir = run_root / args.source_run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    point_dir.mkdir(exist_ok=True)

    reporter = ProgressReporter(
        run_id=args.run_id,
        workflow="OH_CRCC24_BASIS_TRANSFER",
        status_file=run_dir / "status.json",
    )

    exact_t4_dz = load_exact_t4_dz(source_run_dir)

    neutral_geom, anion_geom = load_reference_geometries(
        run_dir=run_root / args.reference_run_id,
        reference_basis=args.reference_basis,
    )
    geoms = {
        "neutral": neutral_geom.r_angstrom,
        "anion": anion_geom.r_angstrom,
    }

    if not hasattr(Driver, "run_ccp4"):
        raise RuntimeError("Installed CCpy Driver lacks run_ccp4")
    for basis in BASIS_BY_X.values():
        for atom in ("O", "H"):
            gto.basis.load(basis, atom)

    completed = [
        "REFERENCE_GEOMETRIES_LOADED",
        "EXACT_FULL_T4_DZ_ANCHOR_LOADED",
        "CCPY_CRCC24_API_VERIFIED",
    ]

    results = {}
    for x in (2, 3):
        basis = BASIS_BY_X[x]
        for role in ("neutral", "anion"):
            label = f"X{x}:{role}:CRCC23_CRCC24"
            reporter.update(
                current_step=f"CALCULATE_{label}",
                completed_steps=completed,
                next_steps=["SAVE_POINT", "CONTINUE_CRCC24_TRANSFER"],
                details={
                    "basis": basis,
                    "role": role,
                    "methods": ["CCSD", "CR-CC(2,3)", "CR-CC(2,4)"],
                    "variants": list(VARIANTS),
                    "correlation_space": "FROZEN_CORE",
                },
            )
            results[(x, role)] = run_cr_pair(
                role=role,
                basis=basis,
                cardinal=x,
                r_angstrom=geoms[role],
                point_dir=point_dir,
                max_memory_mb=args.max_memory_mb,
            )
            completed.append(label)

    q_like = {}
    method_eas = {}
    for x in (2, 3):
        ea23 = ea_by_variant(
            results[(x, "neutral")],
            results[(x, "anion")],
            "crcc23_total_hartree",
        )
        ea24 = ea_by_variant(
            results[(x, "neutral")],
            results[(x, "anion")],
            "crcc24_total_hartree",
        )
        method_eas[x] = {
            "crcc23_ev": ea23,
            "crcc24_ev": ea24,
        }
        q_like[x] = {v: ea24[v] - ea23[v] for v in VARIANTS}

    evidence = build_crcc24_transfer_evidence(
        exact_full_t4_dz_ev=exact_t4_dz,
        q_like_dz_ev=q_like[2],
        q_like_tz_ev=q_like[3],
        central_variant="D",
    )

    payload = evidence.to_dict()
    payload.update({
        "run_id": args.run_id,
        "source_run_id": args.source_run_id,
        "reference_run_id": args.reference_run_id,
        "basis_family": "aug-cc-pVXZ",
        "cardinals": [2, 3],
        "correlation_space": "FROZEN_CORE",
        "method_electron_affinities_ev": method_eas,
        "definition": {
            "q_like_X_L": "EA_CRCC24_X(L) - EA_CRCC23_X(L)",
            "basis_transfer_X": "q_like_X(TZ) - q_like_X(DZ)",
            "anchored_t4_tz_X": "exact_full_T4_DZ + basis_transfer_X",
        },
        "scope": [
            "CR-CC(2,4) is not identified with CCSDT(Q) or full CCSDTQ.",
            "CR-CC hierarchy is used only for DZ-to-TZ basis transfer.",
            "Exact CCSDTQ-CCSDT aug-DZ remains the absolute anchor.",
            "All CR variants A/B/C/D are retained as model diagnostics.",
        ],
        "next": [
            "REVIEW_CRCC24_BASIS_TRANSFER",
            "DECIDE_CONNECTED_QUADRUPLES_RESOLUTION",
        ],
        "is_production_ea": False,
    })

    result_path = run_dir / "result.json"
    result_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    reporter.completed(
        current_step="CRCC24_BASIS_TRANSFER_EVIDENCE_READY",
        completed_steps=completed + ["CRCC24_TRANSFER_ASSESSED"],
        next_steps=payload["next"],
        details={
            "central_basis_transfer_ev": evidence.central_basis_transfer_ev,
            "central_t4_tz_estimate_ev": evidence.central_t4_tz_estimate_ev,
            "transfer_variant_span_ev": evidence.transfer_variant_span_ev,
            "dz_anchor_mismatch_central_ev": evidence.dz_anchor_mismatch_central_ev,
            "result_file": str(result_path),
        },
    )

    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
