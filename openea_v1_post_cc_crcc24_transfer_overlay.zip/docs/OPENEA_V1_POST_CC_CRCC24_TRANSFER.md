# OpenEA v1 — CR-CC(2,4) basis-transfer evidence

PySCF 2.14 does not implement unrestricted CCSDT(Q), so the W4-style
`CCSDT(Q)` route cannot be applied directly to open-shell neutral OH.

The installed CCpy commit does implement CR-CC(2,4) through
`Driver.run_ccp4(method="crcc24")`, including unrestricted/open-shell spin
blocks.

OpenEA does **not** equate CR-CC(2,4) with CCSDT(Q) or full CCSDTQ.

Instead, the CR hierarchy is used only as a basis-transfer model.

For each CR denominator variant X = A/B/C/D and cardinal L,

    q_X(L) = EA[CR-CC(2,4)_X](L) - EA[CR-CC(2,3)_X](L)

The estimated change in the connected-quadruples contribution between aug-DZ
and aug-TZ is

    transfer_X = q_X(TZ) - q_X(DZ).

The directly computed frozen-core full iterative value

    T4_full(DZ) = EA[CCSDTQ](DZ) - EA[CCSDT](DZ)

remains the absolute anchor.  The transferred estimate is

    T4_est_X(TZ) = T4_full(DZ) + transfer_X.

Variant D is used as the central transfer model because it retains the most
complete denominator treatment in the CR hierarchy.  A/B/C/D are all retained
to quantify model sensitivity.

The layer reports, but does not automatically clear:

- the D-variant basis transfer;
- the A-D transfer span and half-range;
- the D-variant discrepancy from the exact full-T4 DZ anchor;
- all CR-CC(2,3) and CR-CC(2,4) electron affinities.

The evidence must be reviewed before the connected-quadruples correction can be
accepted into the global OpenEA uncertainty model.
