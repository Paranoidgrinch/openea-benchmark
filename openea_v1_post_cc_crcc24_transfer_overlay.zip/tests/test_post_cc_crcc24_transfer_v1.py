from openea_benchmark.attachment.post_cc_crcc24_transfer import (
    build_crcc24_transfer_evidence,
)


def test_crcc24_is_used_only_as_basis_transfer():
    dz = {"A": 0.010, "B": 0.011, "C": 0.012, "D": 0.013}
    tz = {"A": 0.012, "B": 0.014, "C": 0.016, "D": 0.018}
    e = build_crcc24_transfer_evidence(
        exact_full_t4_dz_ev=0.020,
        q_like_dz_ev=dz,
        q_like_tz_ev=tz,
    )
    assert abs(e.central_basis_transfer_ev - 0.005) < 1e-15
    assert abs(e.central_t4_tz_estimate_ev - 0.025) < 1e-15
    # Central absolute CR value is not substituted for the exact anchor.
    assert e.central_t4_tz_estimate_ev != tz["D"]


def test_variant_spread_is_retained():
    dz = {"A": 0.010, "B": 0.010, "C": 0.010, "D": 0.010}
    tz = {"A": 0.011, "B": 0.012, "C": 0.013, "D": 0.014}
    e = build_crcc24_transfer_evidence(
        exact_full_t4_dz_ev=0.020,
        q_like_dz_ev=dz,
        q_like_tz_ev=tz,
    )
    assert abs(e.transfer_variant_span_ev - 0.003) < 1e-15
    assert abs(e.transfer_variant_half_range_ev - 0.0015) < 1e-15


def test_dz_anchor_mismatch_is_diagnostic_not_silenced():
    dz = {"A": 0.005, "B": 0.006, "C": 0.007, "D": 0.008}
    tz = {"A": 0.006, "B": 0.007, "C": 0.008, "D": 0.009}
    e = build_crcc24_transfer_evidence(
        exact_full_t4_dz_ev=0.020,
        q_like_dz_ev=dz,
        q_like_tz_ev=tz,
    )
    assert abs(e.dz_anchor_mismatch_central_ev - (-0.012)) < 1e-15
    assert e.status == "EVIDENCE_READY"
    assert e.is_production_ea is False
