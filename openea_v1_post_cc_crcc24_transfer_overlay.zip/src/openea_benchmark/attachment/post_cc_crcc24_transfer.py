"""CR-CC(2,4)-based basis-transfer evidence for connected quadruples.

This module does *not* identify CR-CC(2,4) with CCSDT(Q) or full CCSDTQ.

At a given cardinal L and CR variant X in A/B/C/D, define the incremental
quadruples-like contribution inside the CR hierarchy as

    q_X(L) = EA[CR-CC(2,4)_X](L) - EA[CR-CC(2,3)_X](L)

The CR hierarchy is used only to estimate the change in that incremental
contribution from aug-DZ to aug-TZ,

    transfer_X = q_X(TZ) - q_X(DZ).

The directly computed full iterative CCSDTQ-CCSDT aug-DZ electron-affinity
increment remains the anchor:

    T4_transfer_X(TZ) = T4_full(DZ) + transfer_X.

Variant D is reported as the central transfer model.  A/B/C/D transfer spread
and the discrepancy between q_D(DZ) and the exact full-T4 DZ anchor are
retained as diagnostics.  No automatic production-EA clearance is issued.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping


VARIANTS = ("A", "B", "C", "D")


@dataclass(frozen=True)
class CRCC24TransferEvidence:
    status: str
    action: str
    exact_full_t4_dz_ev: float
    q_like_dz_ev: Mapping[str, float]
    q_like_tz_ev: Mapping[str, float]
    basis_transfer_ev: Mapping[str, float]
    anchored_t4_tz_estimate_ev: Mapping[str, float]
    central_variant: str
    central_basis_transfer_ev: float
    central_t4_tz_estimate_ev: float
    transfer_variant_span_ev: float
    transfer_variant_half_range_ev: float
    dz_anchor_mismatch_central_ev: float
    evidence: tuple[str, ...]
    is_production_ea: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_crcc24_transfer_evidence(
    *,
    exact_full_t4_dz_ev: float,
    q_like_dz_ev: Mapping[str, float],
    q_like_tz_ev: Mapping[str, float],
    central_variant: str = "D",
) -> CRCC24TransferEvidence:
    for variant in VARIANTS:
        if variant not in q_like_dz_ev or variant not in q_like_tz_ev:
            raise ValueError(f"Missing CR variant {variant}")
    if central_variant not in VARIANTS:
        raise ValueError(f"Unsupported central variant: {central_variant}")

    dz = {v: float(q_like_dz_ev[v]) for v in VARIANTS}
    tz = {v: float(q_like_tz_ev[v]) for v in VARIANTS}
    transfer = {v: tz[v] - dz[v] for v in VARIANTS}
    anchored = {
        v: float(exact_full_t4_dz_ev) + transfer[v]
        for v in VARIANTS
    }

    values = list(transfer.values())
    span = max(values) - min(values)
    half_range = 0.5 * span
    central_transfer = transfer[central_variant]
    central_t4 = anchored[central_variant]
    mismatch = dz[central_variant] - float(exact_full_t4_dz_ev)

    return CRCC24TransferEvidence(
        status="EVIDENCE_READY",
        action="REVIEW_CRCC24_BASIS_TRANSFER",
        exact_full_t4_dz_ev=float(exact_full_t4_dz_ev),
        q_like_dz_ev=dz,
        q_like_tz_ev=tz,
        basis_transfer_ev=transfer,
        anchored_t4_tz_estimate_ev=anchored,
        central_variant=central_variant,
        central_basis_transfer_ev=central_transfer,
        central_t4_tz_estimate_ev=central_t4,
        transfer_variant_span_ev=span,
        transfer_variant_half_range_ev=half_range,
        dz_anchor_mismatch_central_ev=mismatch,
        evidence=(
            "EXACT_CCPY_CCSDTQ_MINUS_CCSDT_DZ_ANCHOR",
            "CRCC24_MINUS_CRCC23_USED_ONLY_AS_BASIS_TRANSFER",
            "CR_VARIANTS_A_B_C_D_RETAINED",
            "VARIANT_D_USED_AS_CENTRAL_TRANSFER_MODEL",
            "NO_CRCC24_EQUALS_CCSDTQ_ASSUMPTION",
            "NO_AUTOMATIC_PRODUCTION_CLEARANCE",
        ),
        is_production_ea=False,
    )
