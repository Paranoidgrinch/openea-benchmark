# OpenEA v1 — Scalar relativity

For the OH validation case, OpenEA evaluates a scalar-relativistic correction
as a same-basis energy difference:

    Delta_SR(X) = EA_SFX2C1E(X) - EA_NR(X)

At each cardinal number both calculations use:

- the same neutral and anion reference geometries;
- the same X2C-recontracted correlation-consistent orbital basis;
- all-electron CCSD(T);
- the same SCF/CC convergence policy.

Basis assignment:

- O: aug-cc-pCVXZ-X2C
- H: aug-cc-pVXZ-X2C

for X = T, Q, 5.

PySCF's spin-free one-electron X2C Hamiltonian is invoked with `sfx2c1e()`.
This layer does not include spin-orbit coupling. SOC is a separate OpenEA
diagnostic/correction.

v1 does not extrapolate the scalar-relativistic increment. It accepts the
highest directly calculated cardinal correction when the change from the
previous cardinal is below the configured threshold (default 0.5 meV).
Otherwise the next cardinal is requested up to 5Z.

The result remains an electronic intermediate and is not a production
adiabatic EA.


## Scope guard

This v1 layer is specifically the **spin-free one-electron X2C** contribution.
It does not contain two-electron relativistic terms, picture-change corrections
to general properties, or SOC. For light OH this is the intended validation
correction. A universal production workflow must separately assess whether
two-electron relativistic terms are negligible before declaring the full
relativistic budget complete.


## Basis-family correction

The initial OH implementation proposed `aug-cc-pwCVXZ-DK` on oxygen.  That
family is not defined for first-row O in the local PySCF/Basis Set Exchange
coverage; the relativistic weighted-core DK family is primarily available for
transition-metal ranges.

Because this layer actually uses the spin-free X2C Hamiltonian, the corrected
OH protocol uses the corresponding X2C recontractions directly:

- O: `aug-cc-pCVTZ/QZ/5Z-X2C`
- H: `aug-cc-pVTZ/QZ/5Z-X2C`

O receives the core-valence X2C family because the scalar correction is
evaluated with all electrons correlated.  H has no inner core shell and uses
the cardinally matched valence X2C family.

The nonrelativistic and SFX2C1E members at a given cardinal number use the
same X2C-recontracted orbital basis.  Thus the reported difference isolates
the Hamiltonian change rather than mixing it with a basis-contraction change.

All requested basis sets are preflighted before any expensive CCSD(T)
calculation starts.
