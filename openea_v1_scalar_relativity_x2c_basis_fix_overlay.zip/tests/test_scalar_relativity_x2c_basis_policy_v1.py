def test_oh_scalar_relativity_uses_x2c_recontracted_families():
    policy = {
        3: {"O": "aug-cc-pcvtz-x2c", "H": "aug-cc-pvtz-x2c"},
        4: {"O": "aug-cc-pcvqz-x2c", "H": "aug-cc-pvqz-x2c"},
        5: {"O": "aug-cc-pcv5z-x2c", "H": "aug-cc-pv5z-x2c"},
    }
    assert all("pcv" in policy[x]["O"] and policy[x]["O"].endswith("-x2c")
               for x in policy)
    assert all("pcv" not in policy[x]["H"] and policy[x]["H"].endswith("-x2c")
               for x in policy)
    assert all("pwcv" not in policy[x]["O"] for x in policy)
