# OpenEA v1 — Scalar relativity

For the OH validation case, OpenEA evaluates a scalar-relativistic correction
as a same-basis energy difference:

    Delta_SR(X) = EA_SFX2C1E(X) - EA_NR(X)

At each cardinal number both calculations use:

- the same neutral and anion reference geometries;
- the same relativistically recontracted DK orbital basis;
- all-electron CCSD(T);
- the same SCF/CC convergence policy.

Basis assignment:

- O: aug-cc-pwCVXZ-DK
- H: aug-cc-pVXZ-DK

for X = T, Q, 5.

PySCF's spin-free one-electron X2C Hamiltonian is invoked with `sfx2c1e()`.
This layer does not include spin-orbit coupling. SOC is a separate OpenEA
diagnostic/correction.

v1 does not extrapolate the scalar-relativistic increment. It accepts the
highest directly calculated cardinal correction when the change from the
previous cardinal is below the configured threshold (default 0.5 meV).
Otherwise the next cardinal is requested up to 5Z.

The result remains an electronic intermediate and is not a production
adiabatic EA.


## Scope guard

This v1 layer is specifically the **spin-free one-electron X2C** contribution.
It does not contain two-electron relativistic terms, picture-change corrections
to general properties, or SOC. For light OH this is the intended validation
correction. A universal production workflow must separately assess whether
two-electron relativistic terms are negligible before declaring the full
relativistic budget complete.
