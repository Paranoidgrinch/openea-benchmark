#!/usr/bin/env python3
"""Resolve OH post-CCSD(T) with a W4-style composite.

Reuses the expensive CCpy evidence already present in the source post-CC run:
  * CCSD(T)/aug-DZ and aug-TZ
  * CCSDT/aug-DZ and aug-TZ
  * CCSDTQ/aug-DZ

Adds only PySCF CCSDT(Q) calculations at aug-DZ and aug-TZ for neutral and
anion.  PySCF 2.14 provides parenthetical (Q) for both RCCSDT and UCCSDT.

The output combines:
  T3-(T) : aug-DZ/aug-TZ inverse-power extrapolation, alpha=2.5
  T4     : 1.10 * [(Q)_aug-TZ + {Q-(Q)}_aug-DZ]

No CCSDTQ/aug-TZ calculation is performed.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path

from pyscf import cc, gto, scf
from pyscf.cc import rccsdt, uccsdt

from openea_benchmark.adaptive.run_feedback import ProgressReporter
from openea_benchmark.attachment.cbs_component_evidence import (
    load_reference_geometries,
)
from openea_benchmark.attachment.post_ccsd_t_w4 import (
    resolve_w4_post_ccsd_t,
)

HARTREE_TO_EV = 27.211386245988
BASIS_BY_X = {2: "aug-cc-pvdz", 3: "aug-cc-pvtz"}


def default_run_id() -> str:
    return os.environ.get("OPENEA_RUN_ID") or (
        "oh_post_ccsdt_w4_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    )


def load_json(path: Path) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))


def ccpy_point_path(source_run_dir: Path, x: int, role: str, method: str) -> Path:
    safe = method.replace("(", "").replace(")", "")
    return source_run_dir / "points" / f"X{x}__{role}__{safe}.json"


def load_completed_ccpy_point(
    source_run_dir: Path,
    *,
    x: int,
    role: str,
    method: str,
    basis: str,
) -> dict:
    p = ccpy_point_path(source_run_dir, x, role, method)
    data = load_json(p)
    if (
        data.get("status") != "COMPLETED"
        or data.get("role") != role
        or data.get("method") != method
        or data.get("basis") != basis
    ):
        raise RuntimeError(f"Invalid source CCpy point: {p}")
    return data


def ea_from_points(neutral: dict, anion: dict) -> float:
    return (
        float(neutral["total_energy_hartree"])
        - float(anion["total_energy_hartree"])
    ) * HARTREE_TO_EV


def make_mf(*, role: str, basis: str, r_angstrom: float, max_memory_mb: int):
    charge = 0 if role == "neutral" else -1
    spin = 1 if role == "neutral" else 0
    mol = gto.M(
        atom=f"O 0 0 0; H 0 0 {r_angstrom}",
        basis=basis,
        charge=charge,
        spin=spin,
        unit="Angstrom",
        symmetry=False,
        cart=False,
        verbose=0,
        max_memory=max_memory_mb,
    )
    mf = scf.ROHF(mol) if spin else scf.RHF(mol)
    mf.conv_tol = 1.0e-10
    mf.max_cycle = 150
    mf.kernel()
    if not mf.converged:
        mf2 = mf.newton()
        mf2.conv_tol = 1.0e-10
        mf2.max_cycle = 150
        mf2.kernel(mo_coeff=mf.mo_coeff, mo_occ=mf.mo_occ)
        mf = mf2
    if not mf.converged:
        raise RuntimeError(f"SCF failed for {role} {basis}")
    return mf


def run_pyscf_ccsdt_q(
    *,
    role: str,
    basis: str,
    cardinal: int,
    r_angstrom: float,
    point_dir: Path,
    max_memory_mb: int,
) -> dict:
    path = point_dir / f"X{cardinal}__{role}__PYSCF_CCSDT_Q.json"
    if path.is_file():
        data = load_json(path)
        if (
            data.get("status") == "COMPLETED"
            and data.get("role") == role
            and data.get("basis") == basis
            and abs(float(data.get("r_angstrom")) - r_angstrom) <= 1.0e-10
        ):
            return data

    mf = make_mf(
        role=role,
        basis=basis,
        r_angstrom=r_angstrom,
        max_memory_mb=max_memory_mb,
    )
    mycc = cc.CCSDT(mf, frozen=1)
    mycc.conv_tol = 1.0e-8
    if hasattr(mycc, "conv_tol_normt"):
        mycc.conv_tol_normt = 1.0e-7
    mycc.max_cycle = 100
    mycc.verbose = 4
    mycc.kernel()
    if not getattr(mycc, "converged", False):
        raise RuntimeError(f"PySCF CCSDT failed for {role} {basis}")

    q_raw = mycc.ccsdt_q()
    if not isinstance(q_raw, tuple) or len(q_raw) != 2:
        raise RuntimeError(
            "Unexpected PySCF CCSDT(Q) return value; expected ([Q], (Q)) tuple, "
            f"got {q_raw!r}"
        )
    q_bracket = float(q_raw[0])
    q_paren = float(q_raw[1])

    e_ccsdt = float(mycc.e_tot)
    e_ccsdt_q = e_ccsdt + q_paren
    payload = {
        "status": "COMPLETED",
        "engine": "PySCF",
        "method": "CCSDT(Q)",
        "role": role,
        "basis": basis,
        "cardinal": cardinal,
        "r_angstrom": r_angstrom,
        "nfrozen_spatial_orbitals": 1,
        "reference_type": "ROHF->UCCSDT" if role == "neutral" else "RHF->RCCSDT",
        "ccsdt_total_hartree": e_ccsdt,
        "q_bracket_hartree": q_bracket,
        "q_parenthetical_hartree": q_paren,
        "ccsdt_q_total_hartree": e_ccsdt_q,
    }
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return payload


def ea_pyscf_ccsdt(neutral: dict, anion: dict) -> float:
    return (
        float(neutral["ccsdt_total_hartree"])
        - float(anion["ccsdt_total_hartree"])
    ) * HARTREE_TO_EV


def ea_pyscf_ccsdt_q(neutral: dict, anion: dict) -> float:
    return (
        float(neutral["ccsdt_q_total_hartree"])
        - float(anion["ccsdt_q_total_hartree"])
    ) * HARTREE_TO_EV


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source-run-id", default="oh_post_ccsdt_20261006")
    p.add_argument("--reference-run-id", default="oh_diffuse_x5_resume_20261003")
    p.add_argument("--reference-basis", default="d-aug-cc-pv5z")
    p.add_argument("--run-root", default="runs")
    p.add_argument("--run-id", default=default_run_id())
    p.add_argument("--max-memory-mb", type=int, default=96000)
    p.add_argument("--triples-alpha", type=float, default=2.5)
    p.add_argument("--t4-scale", type=float, default=1.10)
    p.add_argument("--cross-code-tolerance-ev", type=float, default=0.001)
    args = p.parse_args()

    run_root = Path(args.run_root)
    source_run_dir = run_root / args.source_run_id
    run_dir = run_root / args.run_id
    point_dir = run_dir / "points"
    run_dir.mkdir(parents=True, exist_ok=True)
    point_dir.mkdir(exist_ok=True)

    reporter = ProgressReporter(
        run_id=args.run_id,
        workflow="OH_POST_CCSDT_W4_RESOLUTION",
        status_file=run_dir / "status.json",
    )

    # Fail-fast API checks.  PySCF 2.14 exposes (Q) on both restricted and
    # unrestricted CCSDT implementations.
    if not hasattr(cc, "CCSDT"):
        raise RuntimeError("PySCF CCSDT is unavailable")
    if not hasattr(rccsdt.RCCSDT, "ccsdt_q"):
        raise RuntimeError("PySCF RCCSDT.ccsdt_q is unavailable")
    if not hasattr(uccsdt.UCCSDT, "ccsdt_q"):
        raise RuntimeError("PySCF UCCSDT.ccsdt_q is unavailable")
    for basis in BASIS_BY_X.values():
        for atom in ("O", "H"):
            gto.basis.load(basis, atom)

    neutral_geom, anion_geom = load_reference_geometries(
        run_dir=run_root / args.reference_run_id,
        reference_basis=args.reference_basis,
    )
    geoms = {
        "neutral": neutral_geom.r_angstrom,
        "anion": anion_geom.r_angstrom,
    }

    completed = [
        "PYSCF_CCSDT_Q_API_VERIFIED",
        "REFERENCE_GEOMETRIES_LOADED",
        "SOURCE_CCPY_EVIDENCE_LOCATED",
    ]

    # Reuse the CCpy calculations already paid for.
    ccpy = {}
    for x in (2, 3):
        basis = BASIS_BY_X[x]
        for method in ("CCSD(T)", "CCSDT"):
            for role in ("neutral", "anion"):
                ccpy[(x, role, method)] = load_completed_ccpy_point(
                    source_run_dir,
                    x=x,
                    role=role,
                    method=method,
                    basis=basis,
                )
    for role in ("neutral", "anion"):
        ccpy[(2, role, "CCSDTQ")] = load_completed_ccpy_point(
            source_run_dir,
            x=2,
            role=role,
            method="CCSDTQ",
            basis=BASIS_BY_X[2],
        )

    t3 = {}
    full_t4_dz = None
    ccpy_ccsdt_ea = {}
    for x in (2, 3):
        ea_t = ea_from_points(
            ccpy[(x, "neutral", "CCSD(T)")],
            ccpy[(x, "anion", "CCSD(T)")],
        )
        ea_tfull = ea_from_points(
            ccpy[(x, "neutral", "CCSDT")],
            ccpy[(x, "anion", "CCSDT")],
        )
        t3[x] = ea_tfull - ea_t
        ccpy_ccsdt_ea[x] = ea_tfull

    ea_qfull_dz = ea_from_points(
        ccpy[(2, "neutral", "CCSDTQ")],
        ccpy[(2, "anion", "CCSDTQ")],
    )
    full_t4_dz = ea_qfull_dz - ccpy_ccsdt_ea[2]

    # Add only CCSDT(Q) at DZ/TZ with PySCF.
    pyscf_points = {}
    for x in (2, 3):
        basis = BASIS_BY_X[x]
        for role in ("neutral", "anion"):
            label = f"X{x}:{role}:PYSCF_CCSDT(Q)"
            reporter.update(
                current_step=f"CALCULATE_{label}",
                completed_steps=completed,
                next_steps=["SAVE_POINT", "CONTINUE_W4_RESOLUTION"],
                details={
                    "basis": basis,
                    "role": role,
                    "method": "CCSDT(Q)",
                    "engine": "PySCF",
                    "correlation_space": "FROZEN_CORE",
                },
            )
            pyscf_points[(x, role)] = run_pyscf_ccsdt_q(
                role=role,
                basis=basis,
                cardinal=x,
                r_angstrom=geoms[role],
                point_dir=point_dir,
                max_memory_mb=args.max_memory_mb,
            )
            completed.append(label)

    q = {}
    mismatches = {}
    for x in (2, 3):
        ea_ccsdt_ps = ea_pyscf_ccsdt(
            pyscf_points[(x, "neutral")],
            pyscf_points[(x, "anion")],
        )
        ea_ccsdt_q_ps = ea_pyscf_ccsdt_q(
            pyscf_points[(x, "neutral")],
            pyscf_points[(x, "anion")],
        )
        q[x] = ea_ccsdt_q_ps - ea_ccsdt_ps
        mismatches[x] = ea_ccsdt_ps - ccpy_ccsdt_ea[x]

    resolution = resolve_w4_post_ccsd_t(
        triples_dz_ev=t3[2],
        triples_tz_ev=t3[3],
        q_dz_ev=q[2],
        q_tz_ev=q[3],
        full_t4_dz_ev=full_t4_dz,
        cross_code_ccsdt_mismatch_dz_ev=mismatches[2],
        cross_code_ccsdt_mismatch_tz_ev=mismatches[3],
        triples_alpha=args.triples_alpha,
        t4_scale=args.t4_scale,
        cross_code_tolerance_ev=args.cross_code_tolerance_ev,
    )

    payload = resolution.to_dict()
    payload.update({
        "run_id": args.run_id,
        "source_run_id": args.source_run_id,
        "reference_run_id": args.reference_run_id,
        "basis_family": "aug-cc-pVXZ",
        "correlation_space": "FROZEN_CORE",
        "triples_extrapolation": {
            "pair": "aug-cc-pV{D,T}Z",
            "inverse_power_alpha": args.triples_alpha,
        },
        "quadruples_model": {
            "formula": "1.10 * ((Q)_TZ + [CCSDTQ-CCSDT(Q)]_DZ)",
            "scale": args.t4_scale,
            "q_engine": "PySCF CCSDT(Q)",
            "full_q_dz_engine": "CCpy CCSDTQ",
        },
        "uncertainty_note": (
            "triples_extrapolation_shift_ev and t4_scale_sensitivity_ev are "
            "reported as model-sensitivity diagnostics, not yet as the final "
            "OpenEA uncertainty interval."
        ),
        "next_after_clear": [
            "ASSESS_T5_AND_REMAINING_POST_CC_RELEVANCE",
            "ASSESS_TWO_ELECTRON_RELATIVISTIC_RELEVANCE",
            "ASSESS_SOC",
            "SOLVE_NUCLEAR_MOTION",
        ],
        "is_production_ea": False,
    })

    result_path = run_dir / "result.json"
    result_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    reporter.update(
        current_step="ASSESS_W4_POST_CCSDT_RESOLUTION",
        completed_steps=completed,
        next_steps=[resolution.action],
        details=resolution.to_dict(),
    )

    if resolution.status == "CLEARED_COMPOSITE":
        reporter.completed(
            current_step="POST_CCSDT_W4_COMPOSITE_CLEARED",
            completed_steps=completed + ["W4_POST_CCSDT_COMPOSITE_RESOLVED"],
            next_steps=payload["next_after_clear"],
            details={
                "central_correction_ev": resolution.central_correction_ev,
                "triples_cbs_ev": resolution.triples_cbs_ev,
                "t4_w4_ev": resolution.t4_w4_ev,
                "result_file": str(result_path),
            },
        )
    else:
        reporter.blocked(
            current_step="POST_CCSDT_W4_COMPOSITE_NOT_CLEARED",
            completed_steps=completed,
            next_steps=[resolution.action],
            details={"result_file": str(result_path)},
        )

    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
