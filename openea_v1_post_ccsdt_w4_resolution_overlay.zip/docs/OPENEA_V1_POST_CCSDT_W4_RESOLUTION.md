# OpenEA v1 — W4-style post-CCSD(T) resolution

The initial direct post-CCSD(T) probe for OH established three important facts:

1. `T3-(T)` is strongly basis dependent between aug-cc-pVDZ and aug-cc-pVTZ.
2. Full connected quadruples are not negligible at aug-cc-pVDZ.
3. Full CCSDTQ/aug-cc-pVDZ is already expensive enough that a brute-force
   CCSDTQ/aug-cc-pVTZ strategy is inappropriate for an autonomous workflow.

OpenEA therefore switches from a naive "full Q at successive cardinals"
strategy to the established W4-style partitioning of higher-order correlation.

## Higher-order triples

For each cardinal X,

    Delta_T3(X) = EA_CCSDT(X) - EA_CCSD(T)(X)

The v1 W4-resolution layer extrapolates the already computed
aug-cc-pV{D,T}Z increments with

    E(L) = E_inf + A/L^2.5

The exponent 2.5 is the standard W4-family inverse-power model for
`T3-(T)` basis convergence.

The magnitude of the extrapolation shift relative to the TZ increment is
reported explicitly as model sensitivity.

## Connected quadruples

The connected-quadruples contribution is partitioned as

    Delta_(Q)(X) = EA_CCSDT(Q)(X) - EA_CCSDT(X)

and

    Delta_Q-(Q)(DZ)
      = [EA_CCSDTQ - EA_CCSDT](DZ)
        - Delta_(Q)(DZ)

The expensive full-CCSDTQ/aug-DZ evidence already computed with CCpy is
therefore preserved.

PySCF 2.14 supplies CCSDT(Q) for both restricted and unrestricted CCSDT,
allowing the parenthetical `(Q)` contribution to be calculated for the
closed-shell anion and open-shell neutral without proprietary software.

The W4-style T4 estimate is

    Delta_T4 = 1.10 *
      [ Delta_(Q)(aug-TZ) + Delta_Q-(Q)(aug-DZ) ]

No full CCSDTQ/aug-TZ calculation is required.

## Cross-code guard

Because the `(Q)` term is obtained with PySCF while the already-computed full
Q/DZ evidence came from CCpy, OpenEA compares the CCSDT electron affinities
from the two engines at both DZ and TZ.

If either discrepancy exceeds the configured tolerance (default 1 meV), the
workflow fails closed instead of combining incompatible implementations.

## Scope

This is a W4-style composite resolution, not a direct CCSDTQ/CBS result.

The layer reports separate diagnostics for:

- T3 extrapolation sensitivity;
- T4 empirical 1.10 scaling sensitivity;
- CCpy/PySCF CCSDT consistency.

These diagnostics feed the later global OpenEA uncertainty model.

Connected quintuples and higher excitations are not assigned zero.  Their
relevance is assessed in the following workflow gate.
