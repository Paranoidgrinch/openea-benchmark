from openea_benchmark.attachment.post_ccsd_t_w4 import (
    extrapolate_inverse_power,
    resolve_w4_post_ccsd_t,
)


def test_inverse_power_extrapolation_matches_formula():
    low = -0.0015
    high = -0.0110
    got = extrapolate_inverse_power(
        low, high, l_low=2, l_high=3, alpha=2.5
    )
    expected = (
        3.0**2.5 * high - 2.0**2.5 * low
    ) / (3.0**2.5 - 2.0**2.5)
    assert abs(got - expected) < 1e-15


def test_w4_quadruples_formula():
    r = resolve_w4_post_ccsd_t(
        triples_dz_ev=-0.002,
        triples_tz_ev=-0.004,
        q_dz_ev=0.008,
        q_tz_ev=0.010,
        full_t4_dz_ev=0.011,
        cross_code_ccsdt_mismatch_dz_ev=0.0,
        cross_code_ccsdt_mismatch_tz_ev=0.0,
    )
    # residual Q-(Q) = 0.003; W4 T4 = 1.10*(0.010+0.003)
    assert abs(r.iterative_t4_minus_q_dz_ev - 0.003) < 1e-15
    assert abs(r.t4_w4_ev - 0.0143) < 1e-15
    assert r.status == "CLEARED_COMPOSITE"


def test_cross_code_mismatch_fails_closed():
    r = resolve_w4_post_ccsd_t(
        triples_dz_ev=-0.002,
        triples_tz_ev=-0.004,
        q_dz_ev=0.008,
        q_tz_ev=0.010,
        full_t4_dz_ev=0.011,
        cross_code_ccsdt_mismatch_dz_ev=0.0002,
        cross_code_ccsdt_mismatch_tz_ev=0.002,
        cross_code_tolerance_ev=0.001,
    )
    assert r.status == "UNRESOLVED"
    assert r.action == "REVIEW_CCPY_PYSCF_CCSDT_CONSISTENCY"


def test_result_is_explicitly_composite_not_direct_cbs():
    r = resolve_w4_post_ccsd_t(
        triples_dz_ev=-0.002,
        triples_tz_ev=-0.004,
        q_dz_ev=0.008,
        q_tz_ev=0.010,
        full_t4_dz_ev=0.011,
        cross_code_ccsdt_mismatch_dz_ev=0.0,
        cross_code_ccsdt_mismatch_tz_ev=0.0,
    )
    assert r.is_direct_cbs_ccsdtq is False
    assert r.is_production_ea is False
