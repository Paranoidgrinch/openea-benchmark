"""W4-style resolution of OpenEA post-CCSD(T) correlation.

For a molecular electron affinity, all increments are formed as neutral-minus-
anion energy differences at fixed, previously validated geometries.

Higher-order triples:
    dT3(X) = EA[CCSDT] - EA[CCSD(T)]

The CBS estimate is a two-point inverse-power extrapolation of aug-cc-pV{D,T}Z:
    dT3(inf) = (L_hi^a dT3_hi - L_lo^a dT3_lo) /
               (L_hi^a - L_lo^a)
with a = 2.5 by default.

Connected quadruples are partitioned into:
    d(Q)(X)   = EA[CCSDT(Q)] - EA[CCSDT]
    dQ-(Q)(D) = dT4_full(D) - d(Q)(D)

where
    dT4_full(D) = EA[CCSDTQ] - EA[CCSDT]

The W4-style estimate is
    dT4(W4) = 1.10 * ( d(Q)(T) + dQ-(Q)(D) )

This avoids full CCSDTQ/aug-cc-pVTZ while preserving the expensive full-Q DZ
evidence already computed.

The result is explicitly a composite model, not a direct basis-converged
CCSDTQ value.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


def extrapolate_inverse_power(
    low: float,
    high: float,
    *,
    l_low: int,
    l_high: int,
    alpha: float,
) -> float:
    if l_high <= l_low:
        raise ValueError("l_high must exceed l_low")
    if alpha <= 0:
        raise ValueError("alpha must be positive")
    lo = float(l_low) ** alpha
    hi = float(l_high) ** alpha
    return (hi * high - lo * low) / (hi - lo)


@dataclass(frozen=True)
class W4PostCCResolution:
    status: str
    action: str
    triples_cbs_ev: float
    triples_dz_ev: float
    triples_tz_ev: float
    triples_extrapolation_shift_ev: float
    q_dz_ev: float
    q_tz_ev: float
    full_t4_dz_ev: float
    iterative_t4_minus_q_dz_ev: float
    t4_unscaled_composite_ev: float
    t4_w4_ev: float
    t4_scale_sensitivity_ev: float
    central_correction_ev: float
    cross_code_ccsdt_mismatch_dz_ev: float
    cross_code_ccsdt_mismatch_tz_ev: float
    cross_code_tolerance_ev: float
    evidence: tuple[str, ...]
    is_direct_cbs_ccsdtq: bool = False
    is_production_ea: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def resolve_w4_post_ccsd_t(
    *,
    triples_dz_ev: float,
    triples_tz_ev: float,
    q_dz_ev: float,
    q_tz_ev: float,
    full_t4_dz_ev: float,
    cross_code_ccsdt_mismatch_dz_ev: float,
    cross_code_ccsdt_mismatch_tz_ev: float,
    triples_alpha: float = 2.5,
    t4_scale: float = 1.10,
    cross_code_tolerance_ev: float = 0.001,
) -> W4PostCCResolution:
    """Resolve the post-CCSD(T) correction with a W4-style composite.

    ``q_*`` denotes parenthetical CCSDT(Q)-CCSDT contributions, not [Q].
    """
    triples_cbs = extrapolate_inverse_power(
        triples_dz_ev,
        triples_tz_ev,
        l_low=2,
        l_high=3,
        alpha=triples_alpha,
    )
    triples_shift = abs(triples_cbs - triples_tz_ev)

    iterative_residual = full_t4_dz_ev - q_dz_ev
    t4_unscaled = q_tz_ev + iterative_residual
    t4_w4 = t4_scale * t4_unscaled
    scale_sensitivity = abs(t4_w4 - t4_unscaled)
    central = triples_cbs + t4_w4

    mismatch_max = max(
        abs(cross_code_ccsdt_mismatch_dz_ev),
        abs(cross_code_ccsdt_mismatch_tz_ev),
    )
    if mismatch_max > cross_code_tolerance_ev:
        status = "UNRESOLVED"
        action = "REVIEW_CCPY_PYSCF_CCSDT_CONSISTENCY"
    else:
        status = "CLEARED_COMPOSITE"
        action = "NONE"

    return W4PostCCResolution(
        status=status,
        action=action,
        triples_cbs_ev=triples_cbs,
        triples_dz_ev=triples_dz_ev,
        triples_tz_ev=triples_tz_ev,
        triples_extrapolation_shift_ev=triples_shift,
        q_dz_ev=q_dz_ev,
        q_tz_ev=q_tz_ev,
        full_t4_dz_ev=full_t4_dz_ev,
        iterative_t4_minus_q_dz_ev=iterative_residual,
        t4_unscaled_composite_ev=t4_unscaled,
        t4_w4_ev=t4_w4,
        t4_scale_sensitivity_ev=scale_sensitivity,
        central_correction_ev=central,
        cross_code_ccsdt_mismatch_dz_ev=cross_code_ccsdt_mismatch_dz_ev,
        cross_code_ccsdt_mismatch_tz_ev=cross_code_ccsdt_mismatch_tz_ev,
        cross_code_tolerance_ev=cross_code_tolerance_ev,
        evidence=(
            "T3_MINUS_T_EXTRAPOLATED_AUG_DZ_TZ_ALPHA_2P5",
            "PARENTHETICAL_Q_FROM_PYSCF_CCSDT_Q",
            "FULL_ITERATIVE_Q_DZ_FROM_CCPY_CCSDTQ",
            "W4_STYLE_T4_1P10_Q_TZ_PLUS_Q_MINUS_Q_DZ",
            "CROSS_CODE_CCSDT_EA_CONSISTENCY_CHECK",
            "NO_FULL_CCSDTQ_TZ_REQUIRED",
            "COMPOSITE_MODEL_NOT_DIRECT_CCSDTQ_CBS",
        ),
    )
